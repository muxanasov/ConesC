#ifndef CONSTANTS_H
#define CONSTANTS_H

enum {
  SAM_BEACON = 6, // type of serial messages
  BUFFER_SIZE = 255, // send buff. suze is twice as bigger than LOG_SIZE
  LOG_SIZE = 240, // 1 months if loggin is once per 3 hours
  //SAMPLING_INTERVAL = 1000, // 1 sec for testing
  BEACON_INTERVAL = 5000, // 5 sec for testing
  //BSBEACON_TIMEOUT = 10000 // 10 sec for testing
  SERIAL_TIMEOUT = 5000 // 10 secs for testing
};

#endif // CONSTANTS_H
