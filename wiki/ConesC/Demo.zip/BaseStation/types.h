#ifndef TYPES_H
#define TYPES_H

typedef nx_struct BSBeacon {
  nx_uint64_t timestamp;
} BSBeacon;

enum {
  AM_BSBEACON = 5, // magic "AM type for BSBeacon"
  AM_REPORTMSG = 5
};

typedef nx_struct ReportMsg {
  nx_uint64_t timestamp;
  nx_uint16_t temperature;
  nx_uint16_t light;
  nx_uint16_t humidity;
  nx_uint16_t phototsr;
  nx_uint16_t inttemp;
} ReportMsg;

#endif // TYPES_H
