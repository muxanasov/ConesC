#ifndef CONSTANTS_H
#define CONSTANTS_H

enum {
  BUFFER_SIZE = 255, // send buff. suze is twice as bigger than LOG_SIZE
  LOG_SIZE = 240, // 1 months if loggin is once per 3 hours
  SAMPLING_INTERVAL = 1000, //1800000, // 30 mins for testing
  BSBEACON_TIMEOUT = 6000 // 6 sec for testing
};

#endif // CONSTANTS_H
