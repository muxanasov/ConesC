public interface MessageListener {
	public boolean onMessageReceived(ReportMsg msg);
}
