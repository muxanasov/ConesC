import org.LiveGraph.dataFile.write.DataStreamWriter;
import org.LiveGraph.dataFile.write.DataStreamWriterFactory;
import org.LiveGraph.dataFile.common.PipeClosedByReaderException;

import org.LiveGraph.LiveGraph;

public class Plotter implements MessageListener{
	
	private LiveGraph _lg = null;
	private DataStreamWriter _out = null;
	
	public Plotter() {
		// Print a welcome message:
	  System.out.println("Welcome to the ConesC demo.");
	  
	  // Start LiveGraph:
	  _lg = LiveGraph.application();
      _lg.execStandalone();
            
      // Turn LiveGraph into memory mode:
      _out = _lg.updateInvoker().startMemoryStreamMode();
      if (null == _out) {
		System.out.println("Could not switch LiveGraph into memory stream mode.");
		_lg.disposeGUIAndExit();
        return;
      }
	  
	  // Set a values separator:
	  _out.setSeparator(";");
	  
	  // Add a file description line:
	  _out.writeFileInfo("ConesC demo file.");
	  
	  // Set-up the data series:
	  _out.addDataSeries("Light");
	  _out.addDataSeries("Temperature");
	  _out.addDataSeries("Humidity");
	  _out.addDataSeries("PhotoTsr");
	  _out.addDataSeries("InternalTemperature");
	  _out.addDataSeries("Timestamp");
	} 
	  
	public boolean onMessageReceived(ReportMsg msg) {
		
		System.out.println(msg);
		
		  System.out.println("timestamp: " + msg._timestamp
								+ "\ntemperature: " + msg._temperature
								+ "\nlight: " + msg._light
								+ "\nhumidity: " + msg._humidity
								+ "\nphototsr: " + msg._phototsr
								+ "\ninttemp: " + msg._inttemp);
	  
	      _out.setDataValue(msg._light);
	      _out.setDataValue(msg._temperature);
	      _out.setDataValue(msg._humidity);
	      _out.setDataValue(msg._phototsr);
	      _out.setDataValue(msg._inttemp);
	      _out.setDataValue(msg._timestamp);
	      
	      // Write dataset
	      _out.writeDataSet();
	      
	      // If LiveGraph's main window was closed by user, we can finish the demo:
          if (_out.hadIOException()) {
			if (_out.getIOException() instanceof PipeClosedByReaderException) {
				System.out.println("LiveGraph window closed. No reason for more data. Finishing.");
                _out.close();
                System.out.println("Demo finished. Cheers.");
                return false;
			}
          }
                            
          // Check for any other IOErrors and display:                    
          if (_out.hadIOException()) {
			_out.getIOException().printStackTrace();
            _out.resetIOException();
          }
	      
	      // Check for IOErrors:      
	      if (_out.hadIOException()) {
	        _out.getIOException().printStackTrace();
	        _out.resetIOException();
	      }
	      
	      return true;
	}
}
