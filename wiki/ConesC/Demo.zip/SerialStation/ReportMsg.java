import java.nio.ByteBuffer;

public class ReportMsg {
	
	public long _timestamp;
	public short _temperature;
	public short _light;
	public short _phototsr;
	public short _inttemp;
	public short _humidity;
	
	private int _len = 26; // 64_t + 16_t*5 + 64_t (header)
	
	public ReportMsg() {}
	
	public ReportMsg(byte[] packet) {
		if (packet.length != _len) return;
		_inttemp = Utils.createBuffer(packet,24, 26).getShort();
		_phototsr = Utils.createBuffer(packet,22,24).getShort();
		_humidity = Utils.createBuffer(packet,20,22).getShort();
		_light = Utils.createBuffer(packet,18,20).getShort();
		_temperature = Utils.createBuffer(packet,16,18).getShort();
		_timestamp = Utils.createBuffer(packet,8,16).getLong();
	}
	
	public byte[] toByteArray() {
		
		ByteBuffer buffer = ByteBuffer.allocate(_len);
		buffer.putLong(0xFFFF0000120005L); // header
		buffer.putLong(_timestamp);
		buffer.putShort(_temperature);
		buffer.putShort(_light);
		buffer.putShort(_humidity);
		buffer.putShort(_phototsr);
		buffer.putShort(_inttemp);
		
		return buffer.array();
	}
	
	public String toString() {
		return Utils.bytesToHex(toByteArray());
	}
}
