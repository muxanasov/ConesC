import net.tinyos.message.*;
import net.tinyos.util.PrintStreamMessenger;
import net.tinyos.util.Dump;
import net.tinyos.packet.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class SerialListener implements Runnable{
	
	private PhoenixSource _psrc;
	private boolean _running = true;
	
	private MessageListener _messageListener = new MessageListener(){
		public boolean onMessageReceived(ReportMsg msg) {
			System.out.println("MessageListener is not set. Please, use SerialListener.setMessageListener().");
			return false;
		}
	};
	
	public SerialListener(String source) {
		_psrc = BuildSource.makePhoenix(source,PrintStreamMessenger.out);
        _psrc.registerPacketListener(new PacketListenerIF(){
			public void packetReceived(byte[] packet) {
				if(!_running) return;
				
				System.out.println("\nGot the message:\n" + Utils.bytesToHex(packet));
				
				ReportMsg rmsg = new ReportMsg(packet);
				
				if(rmsg._timestamp == 0) {
					System.out.println("Bad packet.");
					return;
				}
					
				//ReportMsg rmsg = new ReportMsg(packet);
				_running = _messageListener.onMessageReceived(rmsg);
			}
		});
		_psrc.start();
	}
	
	public void setMessageListener(MessageListener ml) {
		_messageListener = ml;
	}
	
	public void run() {
		System.out.println("Started...");
		while (_running) {
			
			ReportMsg msg = new ReportMsg();
			msg._timestamp = System.currentTimeMillis();
				
			System.out.println("\nSending a beacon:\n" + msg);
			
			try{
				_psrc.writePacket(msg.toByteArray());
				synchronized (this) {
					wait(4000);
				}
			} catch (Exception e) {
				System.out.println("Something is wrong, sorry...");
				System.out.println(e);
			}
		}
		System.exit(0);
	}
	
}
