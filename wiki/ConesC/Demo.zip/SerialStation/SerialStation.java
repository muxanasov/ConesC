import net.tinyos.packet.BuildSource;

public class SerialStation{
	public static void main(String[] args) {	
		String source = null;
        if (args.length == 2 && args[0].equals("-comm")) {
          source = args[1];
        } else {
            System.err.println("usage: java SerialStation [-comm PACKETSOURCE]");
            System.err.println("PACKETSOURCE values:\n"+BuildSource.sourceHelp());
            System.exit(2);
        }
        
		Plotter plotter = new Plotter();
		SerialListener sl = new SerialListener(source);
		sl.setMessageListener(plotter);
		new Thread(sl).start();
    }
}
